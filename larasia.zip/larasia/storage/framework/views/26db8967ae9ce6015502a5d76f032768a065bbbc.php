<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3><?php echo e(isset($mangkir_blnlalu) ? $mangkir_blnlalu->JmlBlnLalu : 'Nihil'); ?> Kali</h3>
                  <p>Pelanggaran Pegawai Bulan Lalu</p>
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
                <a href="pegawai" class="small-box-footer">Detail pelanggaran <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3><?php echo e($jmlKomp_last_smt->Jumlah); ?> Jam</h3>
                  <p>Semester <?php echo e($jmlKomp_last_smt->Tahun); ?>  </p>
                </div>
                <div class="icon">
                  <i class="ion ion-stats-bars"></i>
                </div>
                <a href="presensi" class="small-box-footer">Detail Pelanggaran <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3>44</h3>
                  <p>User Registrations</p>
                </div>
                <div class="icon">
                  <i class="ion ion-person-add"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <h3>65</h3>
                  <p>Pelanggaran Mahasiswa</p>
                </div>
                <div class="icon">
                  <i class="ion ion-pie-graph"></i>
                </div>
                <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          </div><!-- /.row -->
          <!-- Main row -->
          <div class="row">
            <section class="col-lg-12 connectedSortable">
            <!-- Custom Mangkir-->
              <div class="box box-danger">
                <div class="box-header">
                  <i class="fa fa-pie-chart"></i>
                  <h3 class="box-title">Data Pegawai</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button class="btn bg-teal btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                  </div><!-- /. tools -->
                </div>
                <div class="box-body">
                    <div id="mangkir" style="position: relative; height: 350px;  width: 100%;"></div>
                </div>
                
              </div><!-- /.Mangkir -->
            </section>
            <section class="col-lg-12 connectedSortable">

              
              <!-- kompensasi perprodi-->
              <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-bar-chart"></i>
                  <h3 class="box-title">Pelanggaran Disiplin Mahasiswa</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button class="btn bg-teal btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                  </div><!-- /. tools -->
                </div>
                <div class="box-body">
                    <div id="kompensasi_perprodi" style="position: relative; height: 350px;  width: 100%;"></div>
                </div>
                
              </div><!-- /.kompensasi perprodi -->
            </section>
            <!-- Left col -->
            <section class="col-lg-7 connectedSortable">
              <!-- Custom Kompensasi-->
              <div class="box box-danger">
                <div class="box-header">
                  <i class="fa fa-pie-chart"></i>
                  <h3 class="box-title">Pelanggaran Mahasiswa Per Jurusan</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button class="btn bg-teal btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                  </div><!-- /. tools -->
                </div>
                <div class="box-body">
                    <div id="kompensasi" style="position: relative; height: 350px;  width: 100%;"></div>
                </div>

            </section><!-- /.Left col -->


            <!-- right col (We are only adding the ID to make the widgets sortable)-->
            <section class="col-lg-5 connectedSortable">

              <!-- Custom Mahasiwa-->
              <div class="box box-danger">
                <div class="box-header">
                  <i class="fa fa-pie-chart"></i>
                  <h3 class="box-title">Total Jam Alpha Per Jurusan</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button class="btn bg-teal btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                  </div><!-- /. tools -->
                </div>
                <div class="box-body">
                    <div id="mahasiswa" style="position: relative; height: 350px;  width: 100%;"></div>
                </div>
                
              </div><!-- /.mahasiswa -->             
              
            </section><!-- right col -->
          </div><!-- /.row (main row) -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>


<script type="text/javascript">

    $(function () { 
        
        //var data_pie = <?php //echo $datapie; ?>;
        var tahun_komp = <?php echo $tahun_komp; ?>;
        var data_kompensasi_perprodi = <?php echo $kompensasi_perprodi; ?>;
        var data_kompensasi = <?php echo $kompensasi; ?>;
        var kompensasi_piejurusan = <?php echo $kompensasi_piejurusan; ?>;
        var tahun_mangkir = <?php echo $tahun_mangkir; ?>;
        var data_mangkir = <?php echo $mangkir; ?>;

        //console.log(data_kompensasi);
        //alert(data_pie.toString());
        //console.log(data_pie);
        //console.log("panjang : "+data_pie.length+" data dari pie : "+ data_pie + " --> " );
        

    //Mahasiswa
    $('#mahasiswa').highcharts({

        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },

        title: {
            text: 'Prosentase Jam Alpha per Jurusan'
        },
         subtitle: {
            text: ''
        },

        tooltip: {
            shared: true,
            //headerFormat: '{point.name}',
            pointFormat: '{series.name}: <b>{point.y:.0f}</b> jam'
        },
        
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    //format: '{point.name}: {point.percentage:.1f} %',
                    format: '{point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || '#147bdb',
                        fontSize: 18
                    }
                }
            }
        },
        series: [{
            name: 'Data Mahasiswa',
            colorByPoint: true,        
            data: kompensasi_piejurusan
           
        }]
    });


 //Jam Kompensasi - Keterlambatan Alpha Kuliah
    $('#kompensasi_perprodi').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'column'
        },
        title: {
            text: 'Data Ketidakhadiran Mahasiswa',
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            categories: ['Program Studi']//tahun_komp
             
        },
        yAxis: {
            title: {
                text: 'Jumlah'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ' Jam'
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },

        plotOptions: {
            column: {
                dataLabels: {
                    enabled: true
                }
            },
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                }
            }
        },
        series:  data_kompensasi_perprodi
           
        
    });


    //Jam Kompensasi - Keterlambatan Alpha Kuliah
    $('#kompensasi').highcharts({
        title: {
            text: 'Jam Pelanggaran Mahasiswa Per Semester',
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            categories: tahun_komp
        },
        yAxis: {
            title: {
                text: 'Jumlah'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ' jam'
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },

        plotOptions: {
            column: {
                dataLabels: {
                    enabled: true
                }
            },
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: true
            },
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: data_kompensasi
    });

        //Jam Kompensasi - Keterlambatan Alpha Kuliah
    $('#mangkir').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'column'
            //type:'areaspline'
            //type:'line'
        },
        title: {
            text: 'Pelanggaran Pegawai per Kelompok',
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            categories: tahun_mangkir
            ,
            plotBands: [{ // visualize the weekend
                from: 4.5,
                to: 6.5,
                color: 'rgba(68, 170, 213, .2)'
            }]

        },
        yAxis: {
            title: {
                text: 'Jumlah'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ' kali'
        },
        legend: {
            layout: 'vertical',
            //align: 'right',
            verticalAlign: 'bottom',
            borderWidth: 0
        },

        plotOptions: {
            column: {
                dataLabels: {
                    enabled: true
                }
            },
            line: {
                dataLabels: {
                    enabled: true,
                    color: '#808080'
                },
                enableMouseTracking: true
            },
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: data_mangkir
    });
    
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>