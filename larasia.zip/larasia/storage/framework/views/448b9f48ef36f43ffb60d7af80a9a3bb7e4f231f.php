<html>
	<head>
		<title>Cetak Nilai</title>
	</head>
	<body>
	<style type="text/css">
		table{
			width: 100%;
		}
		table, th, td {
		   /* border: 1px solid black; */
		  
		}
		th, td {
		    padding: 5px;
		    text-align: left;
		   	vertical-align: middle;
		   	border-bottom: 1px solid #ddd;
		   	font-size: 12px;
		}		
		th {
			border-top: 1px solid #ddd;
			height: 20px;
			background-color: #ddd;
			text-align : center;
		}
	</style>
					<center>
					<font size="15">KARTU HASIL STUDI <br>
					POLITEKNIK NEGERI LARASIA INDONESIA<br>
					TAHUN AKADEMIK <?php echo e(substr($semId,0,4)); ?> / <?php echo e(substr($semId,0,4)+1); ?> <?php if(substr($semId,4,1)==1 ): ?> GASAL <?php else: ?> GENAP <?php endif; ?></font>
					<br>
					<hr>
					<br>
					</center>

					<?php if(isset($IPK)): ?>
                        <?php foreach($IPK as $itemIPK): ?>
                            <table >
                                <tbody>
                                <tr>
                                  
                                  <td><b>NIM</b></td>                                  
                                  <td><span class="badge bg-white">: <b> <?php if(!empty($itemIPK->Nim)): ?><?php echo e($itemIPK->Nim); ?> <?php else: ?> - <?php endif; ?> </span></b></td>

                                  <td><b>NAMA</b></td>                                  
                                  <td><span class="badge bg-light-white">: <b><?php if(!empty($itemIPK->mhsNama)): ?><?php echo e($itemIPK->mhsNama); ?> <?php else: ?> - <?php endif; ?></b></span></td>
                                </tr>
                                <tr>
                                  <td>JML SKS IPK</td>                                 
                                  <td><span class="badge bg-yellow">: <?php if($itemIPK->jmlSks > 0): ?><?php echo e($itemIPK->jmlSks); ?> <?php else: ?> 0 <?php endif; ?></span></td>

                                  <td>JML SKS IPS</td>                                 
                                  <td><span class="badge bg-green">: <?php if($IPS->jmlSks > 0): ?><?php echo e($IPS->jmlSks); ?> <?php else: ?> 0 <?php endif; ?> </span></td>
                                </tr>
                                <tr>
                                  
                                  <td>IPK</td>                                  
                                  <td><span class="badge bg-red">: <?php if($itemIPK->IPK > 0): ?><?php echo e($itemIPK->IPK); ?> <?php else: ?> 0 <?php endif; ?> </span></td>

                                  <td>IPS</td>                                  
                                  <td><span class="badge bg-light-blue">: <?php if($IPS->IPS > 0): ?><?php echo e($IPS->IPS); ?> <?php else: ?> 0 <?php endif; ?></span></td>
                                </tr>                                
                               
                              </tbody>
                            </table>
                           
                        <?php endforeach; ?>                        
                    <?php endif; ?>
                    <br>
                    <table >
                    <thead>
                      <tr>    
                        <th>No</th>                    
                        <th>Kode </th>
                        <th width="65%">Matakuliah</th>
                        <th>SKS </th>
                        <th>Nilai</th>                        
                      </tr>
                    </thead>
                    <tbody>
                    <?php if(! empty($dataNilai)): ?>
                     <?php $i=1;foreach ($dataNilai as $itemNilai):  ?>
                      <tr>
                        <td align="center"><?php echo e($i); ?></td>
                        <td><?php echo e($itemNilai->mkkurKode); ?></td>
                        <td><?php echo e($itemNilai->mkkurNama); ?></td>
                        <td align="center"><?php echo e($itemNilai->mkkurJumlahSks); ?></td>
                        <td><?php echo e($itemNilai->krsdtKodeNilai); ?></td>
                       
                      </tr>
                      <?php $i++; endforeach  ?>
                    <?php endif; ?> 
                    </tbody>                    
                  </table>
                  <br>
                  <table border="0" >                    
	                  <tr>
	                    <td width="70%" align="center"></td>
	                    <td align="left">Indonesia, <?php echo e(date('d-m-Y')); ?></td>	                            
	                  </tr>
	                  <tr height="60px">
	                    <td width="70%" align="center"></td>
	                    <td></td>	                            
	                  </tr>              
	                  <tr>
	                    <td width="70%" align="center"></td>
	                    <td align="left"><br><br><br>_________________________</td>	                            
	                  </tr>            
                  </table>
	</body>
</html>