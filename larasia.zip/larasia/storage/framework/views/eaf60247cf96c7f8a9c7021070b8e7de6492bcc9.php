<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
            <li class="active">Dosen</li>
            <li class="active">Detail Dosen</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          
          <div class="row">
            <div class="col-md-12">
              <div class="box box-danger">
                <div class="box-header with-border">
                  <h3 class="box-title">Data Dosen</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
                 <?php foreach ($dosen as $itemDosen);  ?>
                <div class="box-body">
                  <div class="row">
                    <div class="col-md-3">
                      <p align="center">
                        <img src="<?php echo e(URL::asset('admin/dist/img/user-160-nobody.jpg')); ?>" alt="User Image">
                        <a class="users-list-name" href="#"><?php echo e($itemDosen->dsnNama); ?></a>
                        <span class="users-list-date">Dosen Tetap</span>
                      </p>
                    </div><!-- /.col -->
                    <div class="col-md-8">
                     <table id="dataKurikulum" class="table table-bordered table-hover">                    
                      <tbody>
                      
                        <tr>
                          <td>NIDN</td>
                          <td><?php echo e($itemDosen->dsnNidn); ?></td>
                        </tr>
                        <tr>
                          <td>NIP</td>  
                          <td><?php echo e($itemDosen->dsnNip); ?></td>
                        </tr>
                        <tr>
                          <td>Nama</td> 
                          <td><?php echo e($itemDosen->dsnNama); ?></td>
                        </tr>
                        <tr>
                          <td>Program Studi</td> 
                          <td><?php echo e($itemDosen->prodiNama); ?></td> 
                        </tr>
                        <tr>
                          <td>Jurusan</td> 
                          <td><?php echo e($itemDosen->jurNama); ?></td>                        
                        </tr>
                        
                      </tbody>
                      
                    </table>
                    </div><!-- /.col -->
                  </div><!-- /.row -->
                </div><!-- /.box-body -->
                 
              </div>
            </div>
                       
          </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

  

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>