<!DOCTYPE html>
<html>
<head>
	<title>Pelanggan</title>
</head>
<body>
	<h4><?php echo e($pelanggan->nama); ?> </h4><br />
	Pernah transaksi  :
	<ul>		
		<?php foreach($pelanggan->transaksi as $barang): ?>
			<li><?php echo e($barang->nama); ?></li>		
		<?php endforeach; ?>
	</ul>
</body>
</html>