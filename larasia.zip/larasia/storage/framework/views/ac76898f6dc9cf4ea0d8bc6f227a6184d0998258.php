<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
            <li class="active">Pegawai</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          <!-- Awal Graph -->
          <div class="row">
            <div class="col-xs-12">
              <!-- Custom Pegawai-->
               <div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-bar-chart"></i>
                  <h3 class="box-title">Pelanggaran Disiplin Pegawai</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button class="btn bg-teal btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                  </div><!-- /. tools -->
                </div>
                <div class="box-body">
                    <div id="pegawai" style="position: relative; height: 400px;  width: 100%;"></div>
                </div>                
              </div><!-- /.pegawai -->

            </div><!-- /.col -->
          </div><!-- /.row akhir graph-->

          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Data mangkir pegawai dalam per Bulan pada semua Tahun</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="datapegawai" class="table table-bordered table-hover">
                    <thead>
                      <tr>                        
                        <th>Kode Pegawai</th>
                        <th>Nama</th>                        
                        <th>Kelompok</th>                        
                        <th>Mangkir</th>
                        <th>Detail</th>
                      </tr>
                    </thead>
                    <tbody>
                     <?php foreach ($dataMangkir as $itemMangkir):  ?>
                      <tr>
                        <td><?php echo e($itemMangkir->pegKode); ?></td>
                        <td><?php echo e($itemMangkir->pegNama); ?></td>
                        <td><?php echo e($itemMangkir->kelNama); ?></td>                       
                        <td><?php echo e($itemMangkir->Jumlah); ?></td>
                        <td><a href="<?php echo e(URL::to('pegawai/'.$itemMangkir->pegKode.'/detail')); ?>">
                              <span class="label label-info"><i class="fa fa-list"> Detail </i></span>
                              </a></td>
                      </tr>
                      <?php endforeach  ?> 
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>Kode Pegawai</th>
                        <th>Nama</th>                        
                        <th>Kelompok</th>                        
                        <th>Mangkir</th>
                        <th>Detail</th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

            </div><!-- /.col -->
          </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script src="<?php echo e(URL::asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script>
  $(function () {

    //var kategori_mangkir = <?php //echo $kategori_mangkir; ?>;
    var data_mangkir = <?php echo $mangkir; ?>;

        //$("#example1").DataTable();
        /*       $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });*/
    $('#datapegawai').DataTable({"pageLength": 50});

            //Jam Kompensasi - Keterlambatan Alpha Kuliah
    $('#pegawai').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            //type: 'column'
            type:'areaspline'
            //type:'line'
        },
        title: {
            text: 'Pelanggaran Pegawai per Bulan dalam Kelompok',
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            //categories: kategori_mangkir
            categories: ["Januari", "Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"]
            ,
            /*plotBands: [{ // visualize the weekend
                from: 4.5,
                to: 6.5,
                color: 'rgba(68, 170, 213, .2)'
            }]*/

        },
        yAxis: {
            title: {
                text: 'Jumlah'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ' kali'
        },
        legend: {
            layout: 'vertical',
            //layout: 'horizontal',
            //align: 'right',
            verticalAlign: 'bottom',
            borderWidth: 0
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: true
            },
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: data_mangkir
    });

      });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>