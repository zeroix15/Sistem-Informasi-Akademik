<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
            <li class="active">Presensi</li>
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          <!-- Awal Graph -->
          <div class="row">
           
            <div class="col-xs-12">
              <!-- Custom Pegawai-->
               <div class="box box-info">
                
                <div class="box-header">
                  <i class="fa fa-bar-chart"></i>
                  <h3 class="box-title">Pelanggaran Disiplin Mahasiswa</h3>
                  <!-- tools box -->
                  <div class="pull-right box-tools">
                    <button class="btn bg-teal btn-sm" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
                  </div><!-- /. tools -->
                </div>
                <div class="box-body">
                    <div id="mahasiswa" style="position: relative; height: 400px;  width: 100%;"></div>
                </div>
                <div class="box-footer no-border">
                  <form id="formJurusanTambah" class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/presensi/pilihtahun')); ?>">
                  <div class="row">
                    <div class="col-xs-6 text-right" style="border-right: 1px solid #f4f4f4" align="right">
                      <label>Tahun Semester :</label>
                    </div><!-- ./col -->
                    <div class="col-xs-2 text-left" style="border-right: 1px solid #f4f4f4">
                        <div class="form-group">
                         
                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <select name="pilihTahun" id="pilihTahun"   onchange="pilihTahun()"  class="form-control">
                            <?php foreach($tahunform as $itemTahunform): ?>
                                <option value="<?php echo e($itemTahunform->tahun_presensi); ?>" <?php if($itemTahunform->tahun_presensi ==$tahun_terpilih): ?> ? ' selected="selected"' : '' <?php endif; ?> > <?php echo e($itemTahunform->tahun_presensi); ?></option>
                            <?php endforeach; ?>
                            </select>
                          
                        </div>
                    </div><!-- ./col -->
                    <div class="col-xs-2 text-left" style="border-right: 1px solid #f4f4f4">
                      <button type="submit" class="btn btn-primary" id="button-reg">
                      Lihat
                      </button>
                    </div>
                    <!-- ./col -->
                  </div><!-- /.row -->
                  </form>
                </div>
              </div><!-- /.pegawai -->

            </div><!-- /.col -->
          </div><!-- /.row akhir graph-->

          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Data per-Tahun Semester </h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="datapresensi" class="table table-bordered table-hover">
                    <thead>
                      <tr>                        
                        <th>Kode Prodi</th>                        
                        <th>Prodi</th>                        
                        <th>Jurusan</th>
                        <th>Jumlah Mhs</th>
                        <th>Jumlah Jam</th>                        
                        <th>Detail</th>
                      </tr>
                    </thead>
                    <tbody>
                     <?php foreach ($datapresensi as $itemPresensi):  ?>
                      <tr>
                        <td><?php echo e($itemPresensi->prodiKode); ?></td>
                        <td><?php echo e($itemPresensi->prodiNama); ?></td>
                        <td><?php echo e($itemPresensi->jurNama); ?></td> 
                        <td align="right"><?php echo e($itemPresensi->JumlahMhs); ?></td>                      
                        <td align="right"><?php echo e($itemPresensi->JumlahJam); ?></td>
                        <td><a href="<?php echo e(URL::to('presensi/'.$itemPresensi->prodiKode.'/detail')); ?>">
                              <span class="label label-info"><i class="fa fa-list"> Detail </i></span>
                              </a></td>
                      </tr>
                      <?php endforeach  ?> 
                    </tbody>
                    <tfoot>
                      <tr>                        
                        <th>Kode Prodi</th>                        
                        <th>Prodi</th>                        
                        <th>Jurusan</th>
                        <th>Jumlah Mhs</th>
                        <th>Jumlah Jam</th>                        
                        <th>Detail</th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

            </div><!-- /.col -->
          </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script src="<?php echo e(URL::asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('admin/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script>
  $(function() {

    //var kategori_mangkir = <?php //echo $kategori_mangkir; ?>;
    var data_presensi = <?php echo $presensi; ?>;

        //$("#example1").DataTable();
        /*       $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });*/
    $('#datapresensi').DataTable({"pageLength": 10});

            //Jam Kompensasi - Keterlambatan Alpha Kuliah
    $('#mahasiswa').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'column'
            //type:'areaspline'
            //type:'line'
        },
        title: {
            text: 'Jumlah Jam per Prodi',
            x: -20 //center
        },
        subtitle: {
            text: '',
            x: -20
        },
        xAxis: {
            //categories: kategori_mangkir
            //categories: ["Januari", "Pebruari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"]
            categories: ['Program Studi'],
            plotBands: [{ // visualize the weekend
                from: 4.5,
                to: 6.5,
                color: 'rgba(68, 170, 213, .2)'
            }]

        },
        yAxis: {
            title: {
                text: 'Jumlah'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ' jam'
        },
        legend: {
            layout: 'vertical',
            //layout: 'horizontal',
            align: 'right',
            //verticalAlign: 'bottom',
            borderWidth: 0
        },
        plotOptions: {
            column: {
                dataLabels: {
                    enabled: true
                }
            },
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: true
            },
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: data_presensi
    });

  });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>